document.writeln(10+10)
document.writeln(50+50)
console.log(40+40)
console.warn(30+30)